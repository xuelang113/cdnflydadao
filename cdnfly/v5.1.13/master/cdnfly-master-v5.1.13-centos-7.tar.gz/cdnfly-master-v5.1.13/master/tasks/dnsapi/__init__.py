from . import *
from dnspod_cn import Dns
from dnsdotcom import Dns
